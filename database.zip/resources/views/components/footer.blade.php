<footer class="footer-admin mt-auto footer-light" style="background-color:rgb(255, 255, 255);">
    <div class="container-xl px-4">
        <div class="row">
            <div class="col-md-6"><b>Copyright © Ibra & Erlangga 2024</b></div>
        </div>
    </div>
</footer>